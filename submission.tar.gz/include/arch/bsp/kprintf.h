#ifndef KPRINTF_H
#define KPRINTF_H

int kprintf(char *format,...);

#endif