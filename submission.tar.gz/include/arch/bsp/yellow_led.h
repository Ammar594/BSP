#ifndef YELLOW_LED_H
#define YELLOW_LED_H

void yellow_on(void);

#endif
